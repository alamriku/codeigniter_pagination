<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('MReply');
	}

	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function pagination()
	{

	    if($this->input->post())
        {
            $search_text=$this->input->post('search',true);
            $page_search=$this->input->post('page',true);

        }
        else
        {
            $search_text=null;
            $page_search=null;
        }


		$this->load->library("pagination");
		$config = array();
		$config["base_url"] = "#";
		if($search_text != null){
            $config["total_rows"] = $this->MReply->count_all($search_text);


        }
        else
        {
            $config["total_rows"] = $this->MReply->count_all();

        }
        if($this->input->post('per_page'))
        {
            $config["per_page"] = $this->input->post('per_page',true);
        }
        else
        {
            $config["per_page"] = 10;
        }

		$config["uri_segment"] = 3;
		$config["use_page_numbers"] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['attributes'] = array('class' => 'page-link');
		$config['first_link'] = false;
		$config['last_link'] = false;
		$config['first_tag_open'] = '<li class="page-item">';
		$config['first_tag_close'] = '</li>';
		$config['prev_link'] = '&laquo';
		$config['prev_tag_open'] = '<li class="page-item">';
		$config['prev_tag_close'] = '</li>';
		$config['next_link'] = '&raquo';
		$config['next_tag_open'] = '<li class="page-item">';
		$config['next_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li class="page-item">';
		$config['last_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="page-item active"><a href="#" class="page-link">';
		$config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';
		$config['num_tag_open'] = '<li class="page-item">';
		$config['num_tag_close'] = '</li>';
		$config["num_links"] = 1;// means , one link before active link and one link after active link
		$this->pagination->initialize($config);
		if($page_search != null)
        {
            $page= $page_search;
        }
        elseif($this->input->post('page'))
        {
            $page= $this->input->post('page');

        }
        else
        {
            $page = $this->uri->segment(3);
        }

		$start = ($page - 1) * $config["per_page"];

		if($search_text == null)
        {
            $output = array(
                'pagination_link' => $this->pagination->create_links(),
                'country_table' => $this->MReply->fetch_details($config["per_page"], $start)
                //'country_table' => $this->jsonDataFromUrl()
            );
            echo json_encode($output);
        }
        else
        {
            $output = array(
             'pagination_link' => $this->pagination->create_links(),
                'country_table' => $this->MReply->fetch_details($config["per_page"], $start,$search_text)
                //'country_table' => $this->jsonDataFromUrl()
            );
            echo json_encode($output);
        }



	}


	//search button
    public function search_pagination()
    {

        $search_text =$this->input->post('search',true);
        $page_search = $this->input->post('page',true);
        $this->pagination($search_text,$page_search);
    }

    //multiple delete
    public function multiple_delete()
    {
        if($this->input->post())
        {
            $q = $this->MReply->multiple_delete_record();
            echo json_encode($q);
        }
    }



	public function jsonDataFromUrl()
	{
		/*$url = "http://roommatebd.com/auctionapp/get_auction_list.php?searchtype=all&user_id=-1";
		$json = file_get_contents($url);
		$data = json_decode($json, true);*/

		$url = "http://roommatebd.com/auctionapp/get_auction_list.php?searchtype=all&user_id=-1";

		//  Initiate curl
		$ch = curl_init();
		// Will return the response, if false it print the response
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Set the url
		curl_setopt($ch, CURLOPT_URL, $url);
		// Execute
		$result = curl_exec($ch);
		// Closing
		curl_close($ch);

        $result = json_decode($result,true);

//		echo '<pre>';
//		print_r(json_decode($result, true));

        $output = '';
        $output .= '
			  <table class="table table-bordered" id="myTable">
			   <tr>
				<th>ID</th>
				<th>Body</th>
			   </tr>
			  ';
        foreach ($result as $row) {
            $output .= '
						   <tr>
							<td>' . $row['auction_title'] . '</td>
							<td>' . $row['auction_description'] . '</td>
						   </tr>
   			';
        }
        $output .= '</table>';
        return $output;
	}
}
