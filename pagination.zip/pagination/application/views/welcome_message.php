<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$count = $this->db->count_all_results('apps_countries');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
</head>
<body>

<div class="container box">
	<h3 align="center">Ajax JQuery Pagination in Codeigniter using Bootstrap</h3>
    <div class="row">
        <div class="col-md-4">
            <form action="">
                <div class="form-group">
                    <label for="exampleInputEmail1">Search</label>
                    <input type="text" class="form-control"  id="search"  placeholder="Search">
                    <input type="hidden" id="search_page"  value="1">
                </div>

                <button type="button" id="submitBtn" class="btn btn-primary">Submit</button>
                <a href="<?= base_url(); ?>" class="btn btn-primary">Clear Filter</a>

            </form>
            <button class="btn btn-primary" id="deleteAllSelected">Delete Selected</button>
        </div>
        <div class="col-md-4">
            <label for="exampleInputEmail1">Select</label>
            <select class="custom-select" id="select_per_page">
                <option selected>Open this select menu</option>
                <option value="10">10</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="<?= $count ?>">All</option>
            </select>
        </div>
    </div>


	<div class="table-responsive" id="country_table"></div>
	<nav class='text-center' id="pagination_link"></nav>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
		integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
		crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
		integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
		crossorigin="anonymous"></script>

<script>
	$(document).ready(function () {

        function load_country_data(page) {
            $.ajax({
                url: "<?php echo base_url(); ?>welcome/pagination/" + page,
                method: "GET",
                dataType: "json",
                success: function (data) {
                    $('#country_table').html(data.country_table);
                    $('#pagination_link').html(data.pagination_link);

                }
            });
        }

        load_country_data(1);

        $(document).on("click", ".pagination li a", function (event) {
            event.preventDefault();
            var page = $(this).data("ci-pagination-page");

            load_country_data(page);
        });
        $("#submitBtn").on('click', function () {
            let search = $('#search').val();
            let page = $('#search_page').val();
            $.ajax({
                url: "<?php echo base_url(); ?>welcome/pagination",
                method: "POST",
                data: {search: search, page: page},
                dataType: "json",
                success: function (data) {
                    $('#country_table').html(data.country_table);
                    $('#pagination_link').html(data.pagination_link);

                }
            });
        });
        $('#select_per_page').on('change', function () {
            let per_page = $(this).children("option:selected").val();
            page = 1;
            $.ajax({
                url: "<?php echo base_url(); ?>welcome/pagination",
                method: "POST",
                data: {per_page: per_page, page: page},
                dataType: "json",
                success: function (data) {
                    $('#country_table').html(data.country_table);
                    $('#pagination_link').html(data.pagination_link);

                },
            });

        });

        $('#deleteAllSelected').on('click',function () {
            var searchIDs = $("#myTable input:checkbox:checked").map(function(){
                return $(this).val();
            }).get();
            console.log(searchIDs);
            $.ajax({
                url: "<?php echo base_url(); ?>welcome/multiple_delete",
                method: "POST",
                data: {searchIDs: searchIDs},
                dataType: "json",
                success: function (data) {
                    window.location.reload(true);

                },
            });
        })
    });
</script>


</body>
</html>
