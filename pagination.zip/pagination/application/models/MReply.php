<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MReply extends CI_Model
{
	public function get_all($search_text=null)
	{
	    if($search_text != null)
        {
            $this->db->like('country_code', $search_text);
            $this->db->or_like('country_name', $search_text);
            $this->db->or_like('state', $search_text);
            return $this->db->get('apps_countries')->result();
        }
        else
        {
            return $this->db->get('apps_countries')->result();
        }

	}

	public function count_all($search_text=null)
	{
        if($search_text != null)
        {
            $this->db->like('country_code', $search_text);
            $this->db->or_like('country_name', $search_text);
            $this->db->or_like('state', $search_text);
            return $this->db->count_all_results('apps_countries');
        }
        else
        {
            return $this->db->count_all_results('apps_countries');
        }

	}

	public function fetch_details($limit, $start,$search_text=null)
	{
		$output = '';
		if($search_text == null)
        {
            $this->db->select("*");
            $this->db->from("apps_countries");

            $this->db->limit($limit, $start);
            $query = $this->db->get();

            $output .= '
			  <table class="table table-bordered" id="myTable">
			   <tr>
			     <th><input type="checkbox" name="checkAll" value="0" id="checkAll"></th>
				<th>ID</th>
				<th>Body</th>
				<th>State</th>
				<th>Action</th>
			   </tr>
			  ';
            foreach ($query->result() as $row) {
                $output .= '
						   <tr>
						   <td><input type="checkbox" value='.$row->id.'  class="checkbox" name="select" id='.$row->id.' /></td>
							<td>' . $row->country_code . '</td>
							<td>' . $row->country_name . '</td>
							<td>' . $row->state . '</td>
							<td>
							<a class="btn btn-info btn-edit mr-1 btn-sm" href='.base_url().'/welcome/edit/'.$row->id.'>Edit</a>
                                                    <a class="btn btn-danger del btn-sm" href='.base_url().'/welcome/delete/'.$row->id.'>Delete</a>
                            </td>
						   </tr>
   			';
            }
            $output .= '</table>';
            $output .='
            <script>
              $(\'#checkAll\').on(\'click\',function(event) {
            
            if(this.checked) { // check select status
                $(\'.checkbox\').each(function() { //loop through each checkbox
                    this.checked = true;  //select all checkboxes with class "checkbox1"
                });
            }else{
                $(\'.checkbox\').each(function() { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "checkbox1"
                });
            }
        });
</script>
            ';
            return $output;
        }
        else
        {

            $this->db->select("*");
            $this->db->from("apps_countries");
            $this->db->like('country_code', $search_text);
            $this->db->or_like('country_name', $search_text);
            $this->db->or_like('state', $search_text);
            $this->db->limit($limit, $start);
            $query = $this->db->get();

            $output .= '
			  <table class="table table-bordered" id="myTable">
			   <tr>
			     <th><input type="checkbox" value="1"  name="checkAll" id="checkAll"></th>
				<th>ID</th>
				<th>Body</th>
				<th>State</th>
			   </tr>
			  ';
            foreach ($query->result() as $row) {
                $output .= '
						   <tr>
						   <td><input type="checkbox" value='.$row->id.' class="checkbox" name="select" id='.$row->id.' /></td>
							<td>' . $row->country_code . '</td>
							<td>' . $row->country_name . '</td>
							<td>' . $row->state . '</td>
						   </tr>
   			';
            }
            $output .= '</table>';
            $output .='
            <script>
              $(\'#checkAll\').on(\'click\',function(event) {
          
            if(this.checked) { // check select status
                $(\'.checkbox\').each(function() { //loop through each checkbox
                    this.checked = true;  //select all checkboxes with class "checkbox1"
                });
            }else{
                $(\'.checkbox\').each(function() { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "checkbox1"
                });
            }
        });
</script>
            ';
            return $output;
        }

	}

	//multiple delete
    public function multiple_delete_record()
    {
        foreach ($this->input->post('searchIDs',true) as $id)
        {
          $q =  $this->db->where('id',$id)->delete('apps_countries');
        }
        return $q;
    }

}
